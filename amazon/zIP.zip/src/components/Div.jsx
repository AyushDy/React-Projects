const Div = ({ className, styleString, children }) => {
  return <div>{children}</div>;
};
export default Div;
