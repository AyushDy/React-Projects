export const sampleCard1Data1 = [
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: [
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      ],
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
  ];
  
  export const sampleCard1Data2_testing = [
    {
      title: "Custom Appliances for your home | Up to 55% Off",
      items: {
        a: {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        b: {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        c: {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
        d: {
          image: "https://m.media-amazon.com/images/I/41dtRPYZIAL._MCnd_AC_.jpg",
          title: "Air Conditioner",
        },
      },
      redirect: {
        label: "See more",
        url: "https://www.explorin.io",
      },
    },
  ];
  