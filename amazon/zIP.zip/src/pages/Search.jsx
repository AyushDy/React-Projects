import React from "react";
import { useParams, useNavigate } from "react-router-dom";

const Search = ({ searchResults }) => {
  const params = useParams();
  const navigate = useNavigate();

  const handleProductClick = (productId) => {
    navigate(`/product/${productId}`);
  };

  return (
    <div className="p-4">
      {/* Search Bar */}
      <div className="min-w-[198px] min-h-10 flex rounded bg-white overflow-hidden mb-4">
        <input
          className="min-h-full p-2 border-none text-[#111] text-sm flex-1"
          type="search"
          placeholder="Search Amazon.in"
        />
        <button className="min-h-full py-2 px-4 border-none bg-[#febd68] text-black text-sm cursor-pointer">
          🔍
        </button>
      </div>

      {/* Search Results */}
      <div className="flex flex-wrap gap-4">
        {searchResults.map((product) => (
          <div
            key={product.id}
            className="max-w-[240px] flex flex-col items-center border border-gray-200 p-3 rounded-lg cursor-pointer hover:shadow-md"
            onClick={() => handleProductClick(product.id)}
          >
            <img
              src={product.img_link}
              alt={product.product_name}
              className="w-full h-[180px] object-cover mb-2"
            />
            <div className="text-center">
              <h3 className="text-sm font-bold">{product.product_name}</h3>
              <p className="text-md font-semibold text-[#B12704]">
                ₹{product.discounted_price}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Search;
